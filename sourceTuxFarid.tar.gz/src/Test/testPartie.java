/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package Test;

import management.Partie;

/**
 *
 * @author farid
 */
public class testPartie {
    public static void main(String[] args) {    

        Partie partie1 = new Partie("2013-12-11","indice",2);
        
        Partie partie2;
        
        //partie2.getDomElement();
    }
}
